import CardImage from 'components/CardImage';
import FoilOverlay from 'components/FoilOverlay';

const FoilCardImage = FoilOverlay(CardImage);

export default FoilCardImage;
