import React from 'react';

const GroupModalContext = React.createContext();

export default GroupModalContext;
