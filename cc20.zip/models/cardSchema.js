module.exports = {
  tags: [String],
  finish: String,
  colors: [String],
  status: String,
  cmc: Number,
  cardID: String,
  type_line: String,
  imgUrl: String,
  notes: String,
  rating: Number,
};
