import React from 'react';

const CardModalContext = React.createContext(() => null);

export default CardModalContext;
