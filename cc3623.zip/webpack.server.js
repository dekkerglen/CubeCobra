const common = require('./webpack.common.js');

module.exports = common.serverConfig;
