aws ecr get-login-password --region us-east-2 | docker login --username AWS --password-stdin 816705121310.dkr.ecr.us-east-2.amazonaws.com/cubecobra
docker build -t cubecobra .
docker tag cubecobra:latest 816705121310.dkr.ecr.us-east-2.amazonaws.com/cubecobra:latest
docker push 816705121310.dkr.ecr.us-east-2.amazonaws.com/cubecobra:latest