import React from 'react';

const ThemeContext = React.createContext('default');

export default ThemeContext;
